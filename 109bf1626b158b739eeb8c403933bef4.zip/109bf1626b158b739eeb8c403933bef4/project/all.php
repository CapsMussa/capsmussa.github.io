<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
            crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <title>Materials</title>
    <style>
        #color-text {
            color: #1B1B1B;
            font-size: 16px;
            font-weight: 500;
            line-height: 1.2;
        }
    </style>

</head>
<body>
<div class="container">
    <header
            class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">

        <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
            <li><a href="../project/index.php" class="nav-link" id="color-text">Новсти</a></li>
            <li><a href="../project/all.php" class="nav-link" id="color-text">Все курсы </a></li>
        </ul>

        <div class="col-md-3 text-end">
            <button type="button" class="btn btn-outline-dark me-2">Войти</button>
            <button type="button" class="btn btn-dark">Регистрация</button>
        </div>
    </header>
</div>


<div class="container px-4 py-5">
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
        <div class="col-10 col-sm-8 col-lg-6">
        </div>
        <div class="col-lg-6">
            <h1 class="display-5 fw-bold lh-1 mb-3" style="color: #1B1B1B;">Выбери свой курс и освой новый навык</h1>
            <div class="mb-3">
                <input type="text" style="border: 1px solid #1B1B1B;" class="form-control w-50 mt-5"
                       id="formGroupExampleInput" placeholder="Найти курс">
            </div>
        </div>
    </div>


    <div class="row row-cols-1 row-cols-lg-2">
        <div class="feature col" style="width: 350px;">
            <div class="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary">
                <ul class="nav nav-pills flex-column mb-auto">
                    <a href="../project/all.php" class="btn btn-dark mb-1" style="width: fit-content;">Все курсы</a>
                    <a href="#" class="btn btn-outline-dark mb-1" style="width: fit-content;">Рабочие специальности</a>
                    <a href="#" class="btn btn-outline-dark mb-1"
                       style="width: fit-content;">Пром/Электробезопасность</a>
                    <a href="#" class="btn btn-outline-dark mb-1" style="width: fit-content;">Пожарная безопасность</a>
                </ul>
            </div>

        </div>
        <div class="feature col">
            <h1 class="fs-2" style="color: #1B1B1B;">Вся база знаний (1)</h1>
            <div class="row g-4 py-5 row-cols-1 row-cols-lg-2">

                <div class="feature col " style="cursor:pointer; height: 220px;">
                    <a href="../project/malyar.php" class="shadow w-100 p-4 btn btn-outline-dark text-start"
                        style="height: 205px; border-radius: 16px;">
                        <h3 class="fs-6">Маляр</h3>
                        <p style="font-size: 14px;">Специалист по нанесению лакокрасочных материалов на различные поверхности</p>
                    </a>
                </div>

            </div>
        </div>
    </div>
    <div class="container" style="text-align: center;">
        <button class="btn btn-outline-dark fs-5">Еще 10 курсов
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-arrow-right"
                 viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                      d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z"/>
            </svg>
        </button>
    </div>
</div>
<hr>
<div class="container p-5" style="margin-top: 150px;">
    <footer class="py-5">
        <div class="row">
            <div class="col-6 col-md-2 mb-3">
                <h5>Меню</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Новости</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Все курсы </a></li>
                </ul>
            </div>

            <div class="col-6 col-md-2 mb-3">
                <h5>Личный кабинет</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Вход</a></li>
                    <li class="nav-item mb-2"><a href="#"
                                                 class="nav-link p-0 text-body-secondary">Зарегистрироваться</a></li>
                </ul>
            </div>

            <div class="col-6 col-md-2 mb-3">
                <h5>Об услугах</h5>
                <ul class="nav flex-column">
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Лицензия</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Аккредитация</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Помощь</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">О платформе</a></li>
                    <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Контакты</a></li>
                </ul>
            </div>

            <div class="col-md-5 offset-md-1 mb-3">
                <form>
                    <h5>Написать на почту</h5>
                    <p>Укажите Вашу почту</p>
                    <div class="d-flex flex-column flex-sm-row w-100 gap-2">
                        <label for="newsletter1" class="visually-hidden">Адрес почты</label>
                        <input id="newsletter1" type="text" class="form-control w-50" placeholder="Адрес почты">
                        <button class="btn btn-dark" type="button">Отправить</button>
                    </div>
                </form>
            </div>
        </div>
    </footer>
</div>


</body>
</html>
